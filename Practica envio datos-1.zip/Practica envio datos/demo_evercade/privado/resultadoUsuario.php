<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1 - Resultado de Envío</title>
    <?php include("includes/head.php"); ?>
</head>
<body>
    <div class="container">
        <?php include("includes/header.php"); ?>
        <?php include("includes/nav.php"); ?>

        <section class="mt-4">
            <h2 class="text-success">¡Envío Exitoso!</h2>

            <?php
            session_start();
            require_once "clases/Usuario.php";

        
            if (!isset($_SESSION['usuario_id'])) {
                header("Location: altaUsuarios.php");
                exit;
            }

            
            $userId = $_SESSION['usuario_id'];
            $conexion = new Bd();
            $sql = "SELECT * FROM usuarios WHERE id = " . $userId;
            $result = $conexion->getConexion()->query($sql);
            $userData = mysqli_fetch_assoc($result);

            $usuario = new Usuario();
            $usuario->llenarDesdeTupla(
                $userData['id'],
                $userData['nombre'],
                $userData['apellidos'],
                $userData['direccion'],
                $userData['edad'],
                $userData['email'],
                $userData['provincia'],
                $userData['fecha_ult_visita'],
                $userData['telfijo'],
                $userData['telmovil'],
                $userData['tiene_hijos'],
                $userData['avatar']
            );
            $datos = $usuario->getDatos();

            
            $nombreCompleto = $datos['nombre'] . " " . $datos['apellidos'];
            $edad = $datos['edad'];
            $oferta = "";
            if ($edad >= 20 && $edad <= 30) {
                $oferta = "Una televisión de plasma de 65 pulgadas";
            } elseif ($edad >= 31 && $edad <= 60) {
                $oferta = "Un viaje al lugar que decida con todos los gastos pagados.";
            } elseif ($edad > 60) {
                $oferta = "Un bono para visitar gratuitamente cualquier parque de atracciones";
            } else {
                $oferta = "Ninguna, que escriban sus padres.";
            }

            $hijosOferta = $datos['tiene_hijos'] === 'si' 
                ? "le ofreceremos un descuento en consolas de videojuegos" 
                : "no hay oferta adicional";
            ?>

            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h3>Carta de Bienvenida al Usuario</h3>
                </div>
                <div class="card-body">
                    <p class="lead">Estimado/a <?= $nombreCompleto ?>:</p>
                    <p class="lead">Tenemos el placer de comunicarle que en <?= $datos['provincia'] ?> estamos ofreciendo una oferta de productos que le pueden interesar, la oferta consta de:</p>
                    <ul class="list-disc ms-5 lead">
                        <li><?= $oferta ?></li>
                    </ul>
                    <?php if ($datos['tiene_hijos'] === 'si'): ?>
                    <p class="lead">Además, como tiene hijos, le ofrecemos un descuento exclusivo en consolas de videojuegos！</p>
                    <?php endif; ?>
                    <p class="lead text-end mt-5">Atentamente<br>Equipo de Servicio</p>
                </div>
            </div>
        </section>

        <?php include("includes/footer.php"); ?>
    </div>
</body>
</html>