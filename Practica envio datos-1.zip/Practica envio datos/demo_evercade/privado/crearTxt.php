<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 5 - Crear archivo TXT</title>
    <?php include("includes/head.php"); ?>
</head>
<body>
    <div class="container">
        <?php include("includes/header.php"); ?>
        <?php include("includes/nav.php"); ?>

        <section class="mt-4">
            <h2>Crear archivo TXT</h2>
            <?php
            // Recibir el resultado del procesamiento (desde el controlador)
            $mensaje = $_GET['mensaje'] ?? "";
            if (!empty($mensaje)) {
                $tipo = strpos($mensaje, "éxito") !== false ? "success" : "danger";
                echo "<div class='alert alert-{$tipo}'>{$mensaje}</div>";
            }
            ?>

            <form action="controlador/gestionTxt.php" method="POST">
                <div class="mb-3">
                    <label for="contenido" class="form-label">Contenido del archivo</label>
                    <textarea class="form-control" id="contenido" name="contenido" rows="8" required placeholder="Introduzca el contenido del archivo TXT..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Crear archivo TXT</button>
            </form>
        </section>

        <?php include("includes/footer.php"); ?>
    </div>
</body>
</html>