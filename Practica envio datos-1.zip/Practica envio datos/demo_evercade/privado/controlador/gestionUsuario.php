<?php
require_once "../clases/Bd.php";
require_once "../clases/Usuario.php";


$nombre = $_POST['nombre'] ?? "";
$apellidos = $_POST['apellidos'] ?? "";
$direccion = $_POST['direccion'] ?? "";
$edad = $_POST['edad'] ?? 0;
$email = $_POST['email'] ?? "";
$provincia = $_POST['provincia'] ?? "";
$fechaUltVisita = $_POST['fecha_ult_visita'] ?? "";
$telfijo = $_POST['telfijo'] ?? "";
$telmovil = $_POST['telmovil'] ?? "";
$tieneHijos = $_POST['tiene_hijos'] ?? "no";
$avatar = $_FILES['avatar'] ?? [];


$usuario = new Usuario(
    $nombre,
    $apellidos,
    $direccion,
    $edad,
    $email,
    $provincia,
    $fechaUltVisita,
    $telfijo,
    $telmovil,
    $tieneHijos,
    $avatar
);


$datos = $usuario->getDatos();
$error = "";
if (empty($datos['nombre'])) $error .= "Formato de nombre incorrecto<br>";
if (empty($datos['apellidos'])) $error .= "Formato de apellidos incorrecto<br>";
if (empty($datos['edad'])) $error .= "Formato de edad incorrecto<br>";
if (empty($datos['email'])) $error .= "Formato de correo electrónico incorrecto<br>";
if (empty($datos['provincia'])) $error .= "Selección de provincia incorrecta<br>";

//Arregrado por la IA -->
if (!empty($error)) {
    echo "<script>alert('" . $error . "'); window.location.href='../altaUsuario.php';</script>";
} else {
    $usuario->insertarBD();
    session_start();

    if ($usuario->getId()) {
        $_SESSION['usuario_id'] = $usuario->getId();
        header("Location: ../resultadoUsuario.php");
        exit;
    } else {
        echo "<script>alert('Error: No se pudo obtener el ID del usuario insertado. Verifique que la tabla tenga una columna AUTO_INCREMENT llamada id.'); window.location.href='../altaUsuarios.php';</script>";
        exit;
    }
}
?>