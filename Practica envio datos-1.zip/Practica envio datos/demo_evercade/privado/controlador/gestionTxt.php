<?php
$rutaDir = "../archivos/";
if (!is_dir($rutaDir)) {
    mkdir($rutaDir, 0755, true); 
}

$contenido = trim($_POST['contenido'] ?? "");
if (empty($contenido)) {
    $mensaje = "El contenido del archivo no puede estar vacío";
    header("Location: ../crearTxt.php?mensaje=" . urlencode($mensaje));
    exit;
}

$nombreArchivo = "txt_" . time() . ".txt";
$rutaCompleta = $rutaDir . $nombreArchivo;

$archivo = fopen($rutaCompleta, "w");
if ($archivo) {
    fwrite($archivo, $contenido);
    fclose($archivo);
    $mensaje = "¡Archivo txt creado exitosamente! Ruta: " . $rutaCompleta;
} else {
    $mensaje = "Error al crear el archivo, compruebe los permisos del directorio";
}

header("Location: ../crearTxt.php?mensaje=" . urlencode($mensaje));
exit;
?>