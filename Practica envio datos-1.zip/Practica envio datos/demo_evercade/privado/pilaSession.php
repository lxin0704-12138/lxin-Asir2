<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 4 - Gestión de Pila de Sesión</title>
    <?php include("includes/head.php"); ?>
</head>
<body>
    <div class="container">
        <?php include("includes/header.php"); ?>
        <?php include("includes/nav.php"); ?>

        <section class="mt-4">
            <h2>Gestión de Pila de Sesión (LIFO - Último en Entrar, Primero en Salir)</h2>
            <?php
            session_start();

            // Inicializar pila
            if (!isset($_SESSION['pila'])) {
                $_SESSION['pila'] = [];
            }

            $mensaje = "";

            // Manejar "Agregar (Mete)"
            if (isset($_POST['mete'])) {
                $dato = trim($_POST['dato']);
                if (empty($dato)) {
                    $mensaje = "<div class='alert alert-danger'>El dato no puede estar vacío</div>";
                } elseif (strlen($dato) > 20) {
                    $mensaje = "<div class='alert alert-danger'>La longitud del dato no puede exceder los 20 caracteres</div>";
                } else {
                    array_push($_SESSION['pila'], htmlspecialchars($dato));
                    $mensaje = "<div class='alert alert-success'>Dato agregado correctamente</div>";
                }
            }

            // Manejar "Eliminar (Quita)"
            if (isset($_POST['quita'])) {
                if (!empty($_SESSION['pila'])) {
                    array_pop($_SESSION['pila']);
                    $mensaje = "<div class='alert alert-success'>Dato del tope de la pila eliminado correctamente</div>";
                } else {
                    $mensaje = "<div class='alert alert-danger'>La pila está vacía, no se puede eliminar</div>";
                }
            }

            // Manejar "Vaciar (Destruir)"
            if (isset($_POST['destruir'])) {
                $_SESSION['pila'] = [];
                $mensaje = "<div class='alert alert-success'>La pila ha sido vaciada</div>";
            }
            ?>

            <!-- Mensaje de notificación -->
            <?php echo $mensaje; ?>

            <!-- Formulario de operaciones -->
            <form method="POST" class="mb-4">
                <div class="row g-3 align-items-end">
                    <div class="col-md-6">
                        <label for="dato" class="form-label">Introducir dato (≤20 caracteres)</label>
                        <input type="text" class="form-control" id="dato" name="dato" maxlength="20">
                    </div>
                    <div class="col-md-6">
                        <button type="submit" name="mete" class="btn btn-primary me-2">Agregar (Mete)</button>
                        <button type="submit" name="quita" class="btn btn-warning me-2">Eliminar (Quita)</button>
                        <button type="submit" name="destruir" class="btn btn-danger">Vaciar (Destruir)</button>
                    </div>
                </div>
            </form>

            <!-- Visualización del contenido de la pila -->
            <div class="card">
                <div class="card-header">
                    <h3>Contenido Actual de la Pila (Tope → Base)</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($_SESSION['pila'])): ?>
                        <p class="text-muted">La pila está vacía</p>
                    <?php else: ?>
                        <ul class="list-group">
                            <?php
                            // Invertir el array para mostrar desde el tope de la pila
                            $pilaInvertida = array_reverse($_SESSION['pila']);
                            foreach ($pilaInvertida as $index => $item) {
                                $posicion = count($pilaInvertida) - $index;
                                echo "<li class='list-group-item'>Posición {$posicion}：{$item}</li>";
                            }
                            ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <?php include("includes/footer.php"); ?>
    </div>
</body>
</html>