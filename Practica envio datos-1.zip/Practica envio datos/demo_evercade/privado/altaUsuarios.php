<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1 - Formulario de Datos de Usuario</title>
    <?php include("includes/head.php"); ?>
    <script>
        function validarForm() {
            const form = document.altaUsuario;
            let error = "";
            let focusElem = null;

            const nombre = form.nombre.value.trim();
            if (nombre === "" || nombre.length > 50 || !/^[a-zA-Z0-9\s]+$/.test(nombre)) {
                error += "Nombre es obligatorio, solo letras/números/espacios, longitud ≤50 caracteres<br>";
                focusElem = focusElem || form.nombre;
            }

            const apellidos = form.apellidos.value.trim();
            if (apellidos === "" || apellidos.length > 50 || !/^[a-zA-Z0-9\s]+$/.test(apellidos)) {
                error += "Apellidos son obligatorios, solo letras/números/espacios, longitud ≤50 caracteres<br>";
                focusElem = focusElem || form.apellidos;
            }

            const edad = form.edad.value.trim();
            if (edad === "" || !/^[1-9][0-9]?$/.test(edad)) {
                error += "Edad es obligatoria, debe ser un número entre 1 y 99<br>";
                focusElem = focusElem || form.edad;
            }

            const email = form.email.value.trim();
            if (email === "" || !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email)) {
                error += "Correo electrónico es obligatorio, introduzca un formato válido (ej: xxx@xxx.com)<br>";
                focusElem = focusElem || form.email;
            }

            if (form.provincia.value === "") {
                error += "Provincia es obligatoria, seleccione una opción<br>";
                focusElem = focusElem || form.provincia;
            }

            const fecha = form.fecha_ult_visita.value.trim();
            if (fecha === "" || !/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{2}$/.test(fecha)) {
                error += "Fecha de última visita es obligatoria, formato debe ser DD/MM/AA (ej: 01/01/24)<br>";
                focusElem = focusElem || form.fecha_ult_visita;
            }

            const telfijo = form.telfijo.value.trim();
            if (telfijo !== "" && !/^[89]\d{8}$/.test(telfijo)) {
                error += "Formato de teléfono fijo incorrecto (9 dígitos, comienza con 8/9, ej: 912345678)<br>";
                focusElem = focusElem || form.telfijo;
            }

            const telmovil = form.telmovil.value.trim();
            if (telmovil !== "" && !/^\d{9}$/.test(telmovil)) {
                error += "Formato de teléfono móvil incorrecto (9 dígitos numéricos, ej: 612345678)<br>";
                focusElem = focusElem || form.telmovil;
            }

            const tieneHijos = form.tiene_hijos.value;
            if (tieneHijos === "") {
                error += "Seleccione si tiene hijos<br>";
                focusElem = focusElem || form.tiene_hijos[0];
            }

            if (!form.acepta_condiciones.checked) {
                error += "Debe aceptar los términos y condiciones para enviar<br>";
                focusElem = focusElem || form.acepta_condiciones;
            }

            const errorContainer = document.getElementById("error-container");
            if (error !== "") {
                errorContainer.innerHTML = "<div class='alert alert-danger'>" + error + "</div>";
                focusElem.focus();
                return false;
            } else {
                errorContainer.innerHTML = "";
                form.submit();
                return true;
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <?php include("includes/header.php"); ?>
        <?php include("includes/nav.php"); ?>

        <section class="mt-4">
            <h2>Recopilación de Datos de Usuario</h2>
            <form name="altaUsuario" action="controlador/gestionUsuario.php" method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <!-- Nombre -->
                    <div class="col-md-6">
                        <label for="nombre" class="form-label">Nombre (obligatorio)</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" maxlength="50">
                    </div>
                    <!-- Apellidos -->
                    <div class="col-md-6">
                        <label for="apellidos" class="form-label">Apellidos (obligatorio)</label>
                        <input type="text" class="form-control" id="apellidos" name="apellidos" maxlength="50">
                    </div>
                    <!-- Dirección -->
                    <div class="col-12">
                        <label for="direccion" class="form-label">Dirección</label>
                        <textarea class="form-control" id="direccion" name="direccion" rows="2"></textarea>
                    </div>
                    <!-- Edad -->
                    <div class="col-md-3">
                        <label for="edad" class="form-label">Edad (obligatorio)</label>
                        <input type="text" class="form-control" id="edad" name="edad">
                    </div>
                    <!-- Correo electrónico -->
                    <div class="col-md-9">
                        <label for="email" class="form-label">Correo electrónico (obligatorio)</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <!-- Provincia -->
                    <div class="col-md-6">
                        <label for="provincia" class="form-label">Provincia (obligatorio)</label>
                        <select class="form-select" id="provincia" name="provincia">
                            <option value="">Seleccione una provincia</option>
                            <option value="Madrid">Madrid</option>
                            <option value="Barcelona">Barcelona</option>
                            <option value="Valencia">Valencia</option>
                            <option value="Sevilla">Sevilla</option>
                            <option value="Andalucía">Andalucía</option>
                        </select>
                    </div>
                    <!-- Fecha de última visita -->
                    <div class="col-md-6">
                        <label for="fecha_ult_visita" class="form-label">Fecha de última visita (obligatorio, formato: DD/MM/AA)</label>
                        <input type="text" class="form-control" id="fecha_ult_visita" name="fecha_ult_visita" placeholder="01/01/24">
                    </div>
                    <!-- Teléfono fijo -->
                    <div class="col-md-5">
                        <label for="telfijo" class="form-label">Teléfono fijo (opcional, ej: 912345678)</label>
                        <input type="text" class="form-control" id="telfijo" name="telfijo">
                    </div>
                    <!-- Teléfono móvil -->
                    <div class="col-md-5">
                        <label for="telmovil" class="form-label">Teléfono móvil (opcional, ej: 612345678)</label>
                        <input type="text" class="form-control" id="telmovil" name="telmovil">
                    </div>
                    <!-- Avatar (relacionado con Ejercicio 2) -->
                    <div class="col-md-2">
                        <label for="avatar" class="form-label">Avatar (opcional)</label>
                        <input type="file" class="form-control" id="avatar" name="avatar" accept="image/jpeg, image/png, image/gif">
                    </div>
                    <!-- ¿Tiene hijos? -->
                    <div class="col-12">
                        <label class="form-label">¿Tiene hijos? (obligatorio)</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="tiene_hijos" id="hijos-si" value="si">
                            <label class="form-check-label" for="hijos-si">Sí</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="tiene_hijos" id="hijos-no" value="no">
                            <label class="form-check-label" for="hijos-no">No</label>
                        </div>
                    </div>
                    <!-- Aceptar términos -->
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="acepta_condiciones" name="acepta_condiciones">
                            <label class="form-check-label" for="acepta_condiciones">Acepto los términos y condiciones</label>
                        </div>
                    </div>
                    <!-- Contenedor de errores -->
                    <div id="error-container" class="col-12"></div>
                    <!-- Botón de envío -->
                    <div class="col-12">
                        <button type="button" class="btn btn-primary" onclick="validarForm()">Enviar</button>
                    </div>
                </div>
            </form>
        </section>

        <?php include("includes/footer.php"); ?>
    </div>
</body>
</html>