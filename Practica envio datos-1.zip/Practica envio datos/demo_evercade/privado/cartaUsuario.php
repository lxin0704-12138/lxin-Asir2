<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 5b - Carta de Bienvenida al Usuario</title>
    <?php include("includes/head.php"); ?>
</head>
<body>
    <div class="container">
        <?php include("includes/header.php"); ?>
        <?php include("includes/nav.php"); ?>

        <section class="mt-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3>Carta de Bienvenida al Usuario</h3>
                </div>
                <div class="card-body">
                    <p class="lead">Estimado/a [Nombre del Usuario]:</p>
                    <p class="lead">Tengo el places de comunicarle que en provincia estamos ofreciendo una oferta de productos que le pueden interesar, la oferta consta de:</p>
                    <ul>
                        <li>Si tiene entre 20 y 30 años: Una televisión de plasma de 65 pulgadas</li>
                        <li>Si tiene entre 31 y 60 años: Un viaje al lugar que decida con todos los gastos pagados. (todos los gastos pagados)</li>
                        <li>Si tiene más de 60 años: Un bono para visitar gratuitamente cualquier parque de atracciones</li>
                        <li>Si es menor de edad: Ninguna, que escriban sus padres.Además si tiene hijos, le ofrecemos un descuento en consolas ........</li>
                    </ul>
                    <p class="lead">Además, si [tiene/no tiene] hijos, le [ofrecemos un descuento exclusivo en consolas de videojuegos/no hay oferta adicional]!</p>
                    <p class="lead text-end mt-5">Atentamente<br>Equipo de Servicio</p>
                </div>
            </div>
        </section>

        <?php include("includes/footer.php"); ?>
    </div>
</body>
</html>