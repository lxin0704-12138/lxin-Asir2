<?php
require_once "Bd.php";

class ListaUsuarios {
    private $lista;

    public function __construct() {
        $this->lista = array();
    }

    
    public function obtenerBD() {
        $sql = "SELECT * FROM usuarios";
        $conexion = new Bd();
        $resultSQL = $conexion->getConexion()->query($sql);

        while (list($id, $nombre, $apellidos, $direccion, $edad, $email, $provincia, $fecha_ult_visita, $telfijo, $telmovil, $tiene_hijos, $acepta_condiciones, $avatar) = mysqli_fetch_array($resultSQL)) {
            $fila = new Usuario();
            $fila->llenarDesdeTupla($id, $nombre, $apellidos, $direccion, $edad, $email, $provincia, $fecha_ult_visita, $telfijo, $telmovil, $tiene_hijos, $avatar);
            $this->lista[] = $fila;
        }
    }

    
    public function pintarTabla() {
        $html = "<table class='table table-striped' width='100%'>";
        $html .= "<tr><th>Nombre</th><th>Apellidos</th><th>Email</th><th>Provincia</th><th>Edad</th><th>Acciones</th></tr>";
        foreach ($this->lista as $usuario) {
            $html .= $usuario->imprimeFilaTabla();
        }
        $html .= "</table>";
        return $html;
    }
}

class Usuario {
    private $id;
    private $nombre;
    private $apellidos;
    private $direccion;
    private $edad;
    private $email;
    private $provincia;
    private $fecha_ult_visita;
    private $telfijo;
    private $telmovil;
    private $tiene_hijos;
    private $avatar;

    public function __construct($nombre = "", $apellidos = "", $direccion = "", $edad = 0, $email = "", $provincia = "", $fecha_ult_visita = "", $telfijo = "", $telmovil = "", $tiene_hijos = "no", $avatar = []) {
        $this->setNombre($nombre);
        $this->setApellidos($apellidos);
        $this->setDireccion($direccion);
        $this->setEdad($edad);
        $this->setEmail($email);
        $this->setProvincia($provincia);
        $this->setFechaUltVisita($fecha_ult_visita);
        $this->setTelfijo($telfijo);
        $this->setTelmovil($telmovil);
        $this->setTieneHijos($tiene_hijos);
        if (!empty($avatar)) {
            $this->setAvatar($avatar);
        }
    }

    public function llenarDesdeTupla($id, $nombre, $apellidos, $direccion, $edad, $email, $provincia, $fecha_ult_visita, $telfijo, $telmovil, $tiene_hijos, $avatar) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->apellidos = $apellidos;
        $this->direccion = $direccion;
        $this->edad = $edad;
        $this->email = $email;
        $this->provincia = $provincia;
        $this->fecha_ult_visita = $fecha_ult_visita;
        $this->telfijo = $telfijo;
        $this->telmovil = $telmovil;
        $this->tiene_hijos = $tiene_hijos;
        $this->avatar = $avatar;
    }

    public function setNombre($nombre) {
        $nombre = trim(addslashes($nombre));
        if (strlen($nombre) > 0 && strlen($nombre) <= 50 && preg_match('/^[a-zA-Z0-9\s]+$/', $nombre)) {
            $this->nombre = $nombre;
        }
    }

    public function setApellidos($apellidos) {
        $apellidos = trim(addslashes($apellidos));
        if (strlen($apellidos) > 0 && strlen($apellidos) <= 50 && preg_match('/^[a-zA-Z0-9\s]+$/', $apellidos)) {
            $this->apellidos = $apellidos;
        }
    }

    public function setDireccion($direccion) {
        $this->direccion = trim(addslashes($direccion));
    }

    public function setEdad($edad) {
        $edad = intval($edad);
        if ($edad >= 1 && $edad <= 99) {
            $this->edad = $edad;
        }
    }

    public function setEmail($email) {
        $email = trim(addslashes($email));
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->email = $email;
        }
    }

    public function setProvincia($provincia) {
        $provincias = ['Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Andalucía'];
        if (in_array($provincia, $provincias)) {
            $this->provincia = $provincia;
        }
    }

    public function setFechaUltVisita($fecha) {

        $fechaArr = explode('/', $fecha);
        if (count($fechaArr) == 3) {
            $this->fecha_ult_visita = "20" . $fechaArr[2] . "-" . $fechaArr[1] . "-" . $fechaArr[0];
        }
    }

    public function setTelfijo($telfijo) {
        $telfijo = trim($telfijo);

        if (empty($telfijo) || preg_match('/^[89]\d{8}$/', $telfijo)) {
            $this->telfijo = $telfijo;
        }
    }

    public function setTelmovil($telmovil) {
        $telmovil = trim($telmovil);
 
        if (empty($telmovil) || preg_match('/^\d{9}$/', $telmovil)) {
            $this->telmovil = $telmovil;
        }
    }

    public function setTieneHijos($tiene_hijos) {
        if (in_array($tiene_hijos, ['si', 'no'])) {
            $this->tiene_hijos = $tiene_hijos;
        }
    }


    public function setAvatar($avatar) {
        $nombreArchivo = $avatar['name'];
        if (strlen($nombreArchivo) > 0 && strlen($nombreArchivo) < 256 && $avatar['size'] < 5000000) { 
            $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
            $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array($extension, $extensionesPermitidas)) {
                $nombreCustom = "usuario_" . str_replace(' ', '_', $this->nombre) . "_" . time() . "." . $extension;
                if (move_uploaded_file($avatar['tmp_name'], "../img/" . $nombreCustom)) {
                    $this->avatar = $nombreCustom;
                }
            }
        }
    }

    public function getId() { return $this->id; }
    public function getNombre() { return $this->nombre; }
    public function getApellidos() { return $this->apellidos; }
    public function getEdad() { return $this->edad; }
    public function getProvincia() { return $this->provincia; }
    public function getTieneHijos() { return $this->tiene_hijos; }
    public function getAvatar() { return $this->avatar; }
    public function getDatos() {
        return [
            'nombre' => $this->nombre,
            'apellidos' => $this->apellidos,
            'direccion' => $this->direccion,
            'edad' => $this->edad,
            'email' => $this->email,
            'provincia' => $this->provincia,
            'fecha_ult_visita' => $this->fecha_ult_visita,
            'telfijo' => $this->telfijo ?: 'Sin rellenar',
            'telmovil' => $this->telmovil ?: 'Sin rellenar',
            'tiene_hijos' => $this->tiene_hijos
        ];
    }

    //Correcion de IA -->
    public function insertarBD() {
    $bd = new Bd();
    $conexion = $bd->getConexion(); 

    $sql = "INSERT INTO usuarios (nombre, apellidos, direccion, edad, email, provincia, fecha_ult_visita, telfijo, telmovil, tiene_hijos, avatar)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) {
        die("Error en prepare(): " . $conexion->error);
    }

    $stmt->bind_param("sssiisssssi",
        $this->nombre,
        $this->apellidos,
        $this->direccion,
        $this->edad,
        $this->email,
        $this->provincia,
        $this->fecha_ult_visita,
        $this->telfijo,
        $this->telmovil,
        $this->tiene_hijos,
        $this->avatar
    );

    if (!$stmt->execute()) {
        die("Error en execute(): " . $stmt->error);
    }

    $this->id = $conexion->insert_id;

    $stmt->close();
    }   //<--Hasta aqui

    public function imprimeFilaTabla() {
        $avatarHtml = $this->avatar ? "<img width='50' src='img/" . $this->avatar . "' alt='Avatar'>" : "Sin avatar";
        return "<tr>
                    <td>" . $this->nombre . " " . $this->apellidos . "</td>
                    <td>" . $this->email . "</td>
                    <td>" . $this->provincia . "</td>
                    <td>" . $this->edad . "</td>
                    <td>" . $avatarHtml . "</td>
                </tr>";
    }

    public function generarCarta() {
        $edad = $this->edad;
        $oferta = "";
        if ($edad >= 20 && $edad <= 30) {
            $oferta = "Una televisión plasma de 65 pulgadas";
        } elseif ($edad >= 31 && $edad <= 60) {
            $oferta = "Un viaje con todo pagado al destino de su elección";
        } elseif ($edad > 60) {
            $oferta = "Un billete gratuito para cualquier parque de atracciones";
        } else {
            $oferta = "No hay oferta, por favor contacte a sus padres para consultar";
        }
        $descuentoHijos = $this->tiene_hijos == 'si' ? "Además, como tiene hijos, también le ofrecemos un descuento exclusivo en consolas de juegos!" : "";

        return "Estimado/a " . $this->nombre . "：<br><br>
                Nos complace informarle que en la provincia de " . $this->provincia . " estamos lanzando una oferta de productos que podría adaptarse a sus necesidades, la oferta es la siguiente：<br>
                - " . $oferta . "<br><br>
                " . $descuentoHijos;
    }
}
?>