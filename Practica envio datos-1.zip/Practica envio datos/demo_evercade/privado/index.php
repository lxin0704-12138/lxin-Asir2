<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
    include("includes/head.php");
    ?>
</head>
<body>
    <div class="container">
       
        <?php

            include("includes/header.php");
            include("includes/nav.php");



        ?>
      
    <section>
            <h2>Bienvenidos</h2>
            <p>
                Esta es una página web capaz de enviar información a una base de datos. 
            </p>
    </section>

   <?php
        include("includes/footer.php");
   ?>

    </div>  