<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3 - Lista de imágenes</title>
    <?php include("includes/head.php"); ?>
    <style>
        .img-item {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            margin: 10px;
            display: inline-block;
            text-align: center;
            width: 200px;
        }
        .img-item img {
            width: 150px;
            height: auto;
            margin-bottom: 8px;
        }
        .img-item a {
            text-decoration: none;
            color: #0d6efd;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include("includes/header.php"); ?>
        <?php include("includes/nav.php"); ?>

        <section class="mt-4">
            <h2>Lista de imágenes (haga clic para abrir)</h2>
            <div class="d-flex flex-wrap">
                <?php
                $rutaImg = "img/"; // Directorio de imágenes de la plantilla
                if (!is_dir($rutaImg)) {
                    echo "<div class='alert alert-danger'>El directorio de imágenes no existe</div>";
                    exit;
                }

                // Leer archivos del directorio, filtrar por formato de imagen
                $archivos = scandir($rutaImg);
                $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif'];
                $imagenes = [];

                foreach ($archivos as $archivo) {
                    if ($archivo == "." || $archivo == "..") continue;
                    $extension = strtolower(pathinfo($archivo, PATHINFO_EXTENSION));
                    if (in_array($extension, $extensionesPermitidas) && is_file($rutaImg . $archivo)) {
                        $imagenes[] = $archivo;
                    }
                }

                // Mostrar lista de imágenes
                if (empty($imagenes)) {
                    echo "<div class='alert alert-info'>No hay imágenes en el directorio</div>";
                } else {
                    foreach ($imagenes as $img) {
                        // Pasar el nombre del archivo vía $_GET, abrir en una nueva pestaña al hacer clic
                        $imgUrl = $rutaImg . $img;
                        echo "
                            <div class='img-item'>
                                <a href='{$imgUrl}' target='_blank' title='Haga clic para abrir {$img}'>
                                    <img src='{$imgUrl}' alt='{$img}'>
                                    <br>{$img}
                                </a>
                            </div>
                        ";
                    }
                }
                ?>
            </div>
        </section>

        <?php include("includes/footer.php"); ?>
    </div>
</body>
</html>